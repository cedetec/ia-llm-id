# LLM/preprocessing/embedding_builder.py

def construir_texto_embedding(

    documento,

    tipo,

    titulo_padre,

    titulo_hijo,

    subtitulo,

    encabezado_original,

    seccion,

    pagina,

    palabras_clave,

    contenido

):

    """
    Construye el texto enriquecido que será indexado
    en la base vectorial.
    """

    return f"""
DOCUMENTO:
    pass
{documento}

TIPO:
    pass
{tipo}

TÍTULO PADRE:
    pass
{titulo_padre}

TÍTULO HIJO:
    pass
{titulo_hijo}

SUBTÍTULO:
    pass
{subtitulo}

ENCABEZADO:
    pass
{encabezado_original}

SECCIÓN:
    pass
{seccion}

PÁGINA:
    pass
{pagina}

PALABRAS CLAVE:
    pass
{palabras_clave}

CONTENIDO:
    pass

{contenido}
""".strip()