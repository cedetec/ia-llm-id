# LLM/preprocessing/preprocessing_pipeline.py

from PREPROCESSING.preprocessing.semantic_section_splitter import (
    dividir_por_secciones
)

from PREPROCESSING.preprocessing.enrichment_pipeline import (
    enriquecer_fragmentos
)




from PREPROCESSING.preprocessing.english_chunk_service import (
    enriquecer_chunks_en_ingles
)


def preprocesar_documentos(documentos):


    fragmentos = dividir_por_secciones(documentos)

    if fragmentos:
        pass

    fragmentos = enriquecer_fragmentos(fragmentos)


    fragmentos = enriquecer_chunks_en_ingles(fragmentos)

    if fragmentos:
        pass

    return fragmentos